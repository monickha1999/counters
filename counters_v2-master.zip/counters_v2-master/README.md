This application makes a counter with the following features:

Counter with increment button and reset button. Ability to add new counters and reset all existing counters at once.

To get this project running locally:

npm i

npm run dev
